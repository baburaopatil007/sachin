Just a test with some image files to verify the diff.

Credits:

JPGs via Flickr Commons:
  - https://flic.kr/p/pcZiK4
  - https://flic.kr/p/c86ekJ
  - https://flic.kr/p/pRxRda

GIFs via giphy:
  - http://stuff.mousta.ch/post/103315195933/woooo-i-just-released-10-of-my-vj-loops-for-free

PNGs via Creative Commons:
  - https://creativecommons.org/about/downloads/
