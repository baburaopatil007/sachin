# detecting copies

This example should detect copying content into different commits
