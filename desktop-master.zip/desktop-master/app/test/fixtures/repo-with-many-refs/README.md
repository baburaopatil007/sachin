# A Repository With Many Refs

This is mostly crafted so we can test how `for-each-ref` is parsing raw text
from Git.

Things to test:

 - commit with optional body
 - commits with body containing newline characters
 - handles author email being wrapped in `<>`
