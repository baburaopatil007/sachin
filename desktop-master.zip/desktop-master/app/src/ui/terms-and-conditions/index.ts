export { TermsAndConditions } from './terms-and-conditions'
