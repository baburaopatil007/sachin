export const selectedLineClass = 'diff-line-selected'
export const hoverCssClass = 'diff-line-hover'
