/** A remote as defined in Git. */
export interface IRemote {
  readonly name: string
  readonly url: string
}
