export enum PreferencesTab {
  Accounts = 0,
  Git,
  Advanced,
}
